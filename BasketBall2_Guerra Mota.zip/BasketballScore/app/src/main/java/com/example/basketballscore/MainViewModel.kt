package com.example.basketballscore

import android.content.Intent
import android.view.Gravity
import android.widget.Toast
import androidx.core.content.ContextCompat.startActivity
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel:ViewModel() {
    var scoreLocal = MutableLiveData<Int> = MutableLiveData()
    var scoreVisitante = MutableLiveData<Int> = MutableLiveData()

    fun sumadepuntos(){
        scoreLocal.value += 1
    }
    fun restadepuntos(){
        scoreLocal.value - 1
    }
    fun sumadedospuntos(){
        scoreLocal.value += 2
    }
    fun sumadepuntosVisitante(){
        scoreVisitante.value += 1
    }
    fun restadepuntosVisitante(){
        scoreVisitante.value - 1
    }
    fun sumadedospuntosVisitante(){
        scoreVisitante.value += 2
    }

}