package com.example.basketballscore

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.basketballscore.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bundle = intent.extras!!
        val scoreuno = bundle.getString("score_uno") ?:""
        val scoredos = bundle.getString("score_dos") ?:""
        val resultado = bundle.getString("resultado") ?:""
        binding.scoreunoR.text = scoreuno
        binding.scoredosR.text = scoredos
        binding.resultado.text =resultado

        if(scoreuno.toString() > scoredos.toString())
        {
            binding.resultado.text = "Ganó el equipo local 🏆"
        }
        else if (scoreuno.toString() < scoredos.toString())
        {
            binding.resultado.text = "Ganó el equipo visitante 🏆"
        }
        else
        {
            binding.resultado.text = "Empataron 😉"
        }

    }
}