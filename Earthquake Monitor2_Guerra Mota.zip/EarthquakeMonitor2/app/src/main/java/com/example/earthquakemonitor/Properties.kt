package com.example.earthquakemonitor

class Properties(val mag: Double, val place: String, val time: Long)
