package com.example.earthquakemonitor

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import org.json.JSONObject

class MainViewModel: ViewModel() {

    private var _eqList = MutableLiveData<MutableList<Earthquake>>()
    val eqList: LiveData<MutableList<Earthquake>>
        get() = _eqList

    private val repository = MainRepository()

    init{
        /*crear una coroutina que funcione en el main threat*/
        viewModelScope.launch {
                _eqList.value = repository.fetchEarthquakes()
            }
        }
}