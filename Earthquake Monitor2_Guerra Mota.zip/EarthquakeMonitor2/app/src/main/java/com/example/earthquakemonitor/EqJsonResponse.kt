package com.example.earthquakemonitor

class EqJsonResponse(val features: List<Feature>)
